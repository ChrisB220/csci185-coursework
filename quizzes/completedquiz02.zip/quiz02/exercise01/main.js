function showFox() {
    // your code here...
    document.querySelector('img').src = "images/fox.jpg"
    document.querySelector('p').innerText = "Fox"
    console.log('Change image and paragraph to fox...');
}

function showLion() {
    // your code here...
    document.querySelector('img').src = "images/lion.jpg"
    document.querySelector('p').innerText = "Lion"
    console.log('Change image and paragraph to lion...');
}

function showTiger() {
    // your code here...
    document.querySelector('img').src = "images/tiger.png"
    document.querySelector('p').innerText = "Tiger"
    console.log('Change image and paragraph to tiger...');
}

function showZebra() {
    // your code here...
    document.querySelector('img').src = "images/zebra.jpg"
    document.querySelector('p').innerText = "Zebra"
    console.log('Change image and paragraph to zebra...');
}

